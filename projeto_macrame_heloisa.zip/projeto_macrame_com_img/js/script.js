document.addEventListener('DOMContentLoaded', function() {
    const navbar = document.getElementById('mainNavbar');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) navbar.classList.add('scrolled');
        else navbar.classList.remove('scrolled');
    });
    const themeToggleBtn = document.getElementById('themeToggle');
    const body = document.body;
    if(localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-mode');
        themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i> Claro';
    }
    themeToggleBtn.addEventListener('click', function() {
        body.classList.toggle('dark-mode');
        if (body.classList.contains('dark-mode')) {
            themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i> Claro';
            localStorage.setItem('theme', 'dark');
        } else {
            themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i> Escuro';
            localStorage.setItem('theme', 'light');
        }
    });
    const contactForm = document.getElementById('contactForm');
    const formFeedback = document.getElementById('formFeedback');
    contactForm.addEventListener('submit', function(event) {
        event.preventDefault();
        contactForm.classList.remove('was-validated');
        formFeedback.classList.add('d-none');
        formFeedback.classList.remove('alert-success', 'alert-danger');
        let isValid = true;
        const nome = document.getElementById('nome').value.trim();
        const email = document.getElementById('email').value.trim();
        const assunto = document.getElementById('assunto').value.trim();
        const mensagem = document.getElementById('mensagem').value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!nome || !email || !assunto || !mensagem) isValid = false;
        else if (!emailRegex.test(email)) isValid = false;
        if (!isValid) {
            contactForm.classList.add('was-validated');
            formFeedback.textContent = 'Por favor, preencha todos os campos corretamente.';
            formFeedback.classList.add('alert-danger');
            formFeedback.classList.remove('d-none');
        } else {
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
            submitBtn.disabled = true;
            setTimeout(() => {
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
                formFeedback.textContent = `Obrigado, ${nome.split(' ')[0]}! Sua mensagem sobre "${assunto}" foi enviada com sucesso. (Simulação)`;
                formFeedback.classList.add('alert-success');
                formFeedback.classList.remove('d-none');
                contactForm.reset();
                contactForm.classList.remove('was-validated');
            }, 1500);
        }
    });
});