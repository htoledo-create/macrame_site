# Projeto Front-end: Nós & Tramas (SPA de Macramê)

## Sobre o Projeto
Este projeto foi desenvolvido como entrega para a disciplina de Front-end. Trata-se de uma Single Page Application (SPA) para um ateliê fictício de macramê chamado "Nós & Tramas". O objetivo é vender peças artesanais de decoração e acessórios.

## Tecnologias Utilizadas
- **HTML5**: Estruturação semântica da página.
- **CSS3**: Estilização personalizada, criação de variáveis de cores e suporte ao modo escuro.
- **JavaScript (ES6+)**: Interatividade da página, manipulação do DOM e validação de formulários.
- **Bootstrap 5**: Framework CSS utilizado para o sistema de grid, navbar responsiva, cards de produto e carrossel de depoimentos.
- **FontAwesome**: Biblioteca de ícones.

## Recursos Dinâmicos (JavaScript) Implementados
1. **Modo Escuro (Dark Mode)**: Um botão no cabeçalho que alterna o tema do site. A preferência fica salva no `localStorage` do navegador.
2. **Navbar Interativa**: A barra de navegação ganha sombra e cor de fundo sólida dinamicamente ao rolar a página para baixo.
3. **Validação de Formulário Customizada**: O formulário intercepta o envio (`preventDefault`), valida o preenchimento de campos obrigatórios e o formato do e-mail via Regex.
4. **Simulação de Envio Assíncrono**: Após a validação, exibe um _feedback_ de carregamento (spinner) e depois uma mensagem de sucesso, simulando o comportamento de APIs como o Formspree ou EmailJS.

## Como Executar
1. Extraia o conteúdo deste arquivo `.zip`.
2. Certifique-se de que as imagens fornecidas (`image_47d46b.jpg`, `image_47d465.png`, etc.) foram movidas para a pasta `img/` exatamente com esses nomes.
3. Abra o arquivo `index.html` em qualquer navegador web moderno.
4. (Opcional) Para publicar, basta fazer o upload da pasta para o GitHub Pages, Vercel ou Netlify.
